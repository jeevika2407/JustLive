# PeerChat
A peer to peer WebRTC application with controls

# Installation
* 1 - clone repo https://github.com/divanov11/PeerChat
* 2 - Create an account on agora.io and create an app to generate an APP ID
* 3 - Update APP ID, Temp Token and Channel Name in main.js
```javascript
let APP_ID = "YOU-APP-ID"
```


<img src="./images/preview.PNG">  
